=== Night Stalker Backup Restoration Guide ===
Timestamp: 2025-06-16_19-59-04

This backup contains sensitive data required to restore your Night Stalker installation.

1. Database Restoration:
   - Import the SQL dump using: mysql -u [username] -p [database_name] < database/night_stalker_2025-06-16_19-59-04.sql

2. Configuration Files:
   - Copy the 'config' directory to your Night Stalker installation root

3. PHP Include Files:
   - Copy files from the 'includes' directory to your Night Stalker 'includes' directory

4. Other Files:
   - Copy any other files (.env, wallet-auth.php, etc.) to your Night Stalker root directory

IMPORTANT: Keep this backup secure as it contains sensitive information!
