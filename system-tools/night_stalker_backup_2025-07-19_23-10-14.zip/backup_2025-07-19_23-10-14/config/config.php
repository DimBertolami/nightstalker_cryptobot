<?php
// Database configuration constants
// Please update these values with your actual database credentials
define('DB_HOST', 'localhost');
define('DB_NAME', 'nightstalker_db');
define('DB_USER', 'root');
define('DB_PASS', '');
?>
