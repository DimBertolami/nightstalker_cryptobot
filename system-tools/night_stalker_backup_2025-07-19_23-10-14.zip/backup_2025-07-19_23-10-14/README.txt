=== Night Stalker Backup Restoration Guide ===
Timestamp: 2025-07-19_23-10-14

This backup contains sensitive data required to restore your Night Stalker installation.

1. Database Restoration:
   - Import the SQL dump using: mysql -u [username] -p [database_name] < database/NS_2025-07-19_23-10-14.sql

2. Configuration Files:
   - Copy the 'config' directory to your Night Stalker installation root

3. PHP Include Files:
   - Copy files from the 'includes' directory to your Night Stalker 'includes' directory

4. Other Files:
   - Copy any other files (.env, wallet-auth.php, etc.) to your Night Stalker root directory

IMPORTANT: Keep this backup secure as it contains sensitive information!
